#!/usr/bin/env python
# coding: utf-8

import datetime
import logging

from fs_to_dw import read_file_system
from fs_to_dw import json_to_csv
from fs_to_dw import load_pgsql

if __name__ == '__main__':
    
    logging.basicConfig(filename='log/{0}.log'.format(__file__.replace('.py', '')), level=logging.INFO, format='[%(asctime)s %(levelname)s %(name)s] %(message)s')
    logger = logging.getLogger(__name__)
    
    ################################################### parameter ###################################################
    interval = 86400
    period = 365 + 366
    end_interval = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

    while end_interval < datetime.datetime.now():
        end_interval += datetime.timedelta(seconds=interval)
    start_interval = end_interval - datetime.timedelta(seconds=interval)

    parameter = []
    for i in range(period):
        parameter.append(
            {
                "start_interval": (start_interval - datetime.timedelta(seconds=interval * i)).strftime('%Y-%m-%d %H:%M:%S'),
                "end_interval": (end_interval - datetime.timedelta(seconds=interval * i) - datetime.timedelta(seconds=0)).strftime('%Y-%m-%d %H:%M:%S'),
                "year": "year={0}".format((start_interval - datetime.timedelta(seconds=interval * i)).strftime('%Y')),
                "month": "month={0}".format((start_interval - datetime.timedelta(seconds=interval * i)).strftime('%m'))
            }
        )
    #################################################################################################################

    file_system_query = """
        select option as option_nk
             , to_char(created_at, 'yyyyMMdd') as date_sk
             , cast(
                   split(to_char(created_at, 'HH:mm'), ':')[0] * 3600 +
                   case when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 10 then 0
                        when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 20 then 10 * 60
                        when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 30 then 20 * 60
                        when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 40 then 30 * 60
                        when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 50 then 40 * 60
                        else 50 * 60
                   end
               as varchar) as time_sk
             , cast(sum(value) as varchar) as value
             , cast(count(id) as varchar) as amount
             , to_char(created_at, 'yyyy-MM-dd') as `interval` 
          from table(dfs.`/home/danilo/Documents/warehouse/df.csv`(type => 'text', fieldDelimiter => ';', extractHeader => true, schema => 'inline=(id varchar, code integer, option varchar, description varchar, value double, rate double, created_at timestamp properties {`drill.format` = `yyyy-MM-dd HH:mm:ss.SSSSSS`}, updated_at timestamp properties {`drill.format` = `yyyy-MM-dd HH:mm:ss.SSSSSS`}, status boolean)'))
         where /*dir0 = '%(year)s'
           and dir1 = '%(month)s'
           and */created_at >= '%(start_interval)s' and created_at < '%(end_interval)s'
      group by option
             , to_char(created_at, 'yyyyMMdd')
             , split(to_char(created_at, 'HH:mm'), ':')[0] * 3600 +
               case when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 10 then 0
                    when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 20 then 10 * 60
                    when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 30 then 20 * 60
                    when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 40 then 30 * 60
                    when cast(split(to_char(created_at, 'HH:mm'), ':')[1] as integer) < 50 then 40 * 60
                    else 50 * 60
               end
             , to_char(created_at, 'yyyy-MM-dd')
    """
    
    stage_table_creation = """
        create temp table stg_test_interval(
            option_nk character varying,
            date_sk   integer,
            time_sk   integer,
            value     double precision,
            amount    integer,
            interval  date,
            constraint uq_test_interval unique(option_nk, date_sk, time_sk)
        )
    """
    
    table_merge = """
        insert into fact_test_interval(option_sk, date_sk, time_sk, value, amount)
            select case when dim_option.sk is null then -1 else dim_option.sk end as option_sk
                 , stg_test_interval.date_sk
                 , stg_test_interval.time_sk
                 , stg_test_interval.value
                 , stg_test_interval.amount
              from stg_test_interval
         left join dim_option
                on stg_test_interval.option_nk = dim_option.historical_name 
               and stg_test_interval.interval between dim_option.start_date and dim_option.end_date
        on conflict(option_sk, date_sk, time_sk)
        do update set value = excluded.value
                    , amount = excluded.amount
                    , updated_at = current_timestamp at time zone 'UTC'
                where fact_test_interval.value <> fact_test_interval.value
                   or fact_test_interval.amount <> fact_test_interval.amount
    """
    
    try:
        for value in parameter:
            data = read_file_system(file_system_query, value)
            if data:
                output = json_to_csv(data)
                load_pgsql(stage_table_creation, output, table_merge)
            else:
                logger.warning('Query returns empty!')
    except Exception as e:
        logger.critical(e)