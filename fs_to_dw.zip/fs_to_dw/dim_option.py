#!/usr/bin/env python
# coding: utf-8

import datetime
import time
import logging

from fs_to_dw import read_file_system
from fs_to_dw import json_to_csv
from fs_to_dw import load_pgsql

logging.basicConfig(filename='log/{0}.log'.format(__file__.replace('.py', '')), level=logging.INFO, format='[%(asctime)s %(levelname)s %(name)s] %(message)s')
logger = logging.getLogger(__name__)

def main(file_system_query, parameter, stage_table_creation, table_merge):
    try:
        for value in parameter:

            p1 = time.time()
            data = read_file_system(file_system_query, value)
            p1 = time.time() - p1

            if data:

                p2 = time.time()
                output = json_to_csv(data)
                p2 = time.time() - p2

                p3 = time.time()
                rows_number = load_pgsql(stage_table_creation, output, table_merge)
                p3 = time.time() - p3

                logger.info({'message': 'Successfully executed.', 'rows inserted and changed': rows_number, 'read_file_system': round(p1, 2), 'json_to_csv': round(p2, 2), 'load_pgsql': round(p3, 2), 'execution_time': round(p1 + p2 + p3, 2), 'parameter': value})
            else:
                logger.info({'message': 'Query returns empty!', 'rows inserted and changed': rows_number, 'read_file_system': round(p1, 2), 'json_to_csv': round(p2, 2), 'load_pgsql': round(p3, 2), 'execution_time': round(p1 + p2 + p3, 2), 'parameter': value})
    except Exception as e:
        logger.critical(e)

def parameter():
    interval = 86400
    period = 3
    end_interval = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

    while end_interval < datetime.datetime.now():
        end_interval += datetime.timedelta(seconds=interval)
    start_interval = end_interval - datetime.timedelta(seconds=interval)

    parameter = []
    for i in range(period):
        parameter.append(
            {
                "start_interval": (start_interval - datetime.timedelta(seconds=interval * i)).strftime('%Y-%m-%d %H:%M:%S'),
                "end_interval": (end_interval - datetime.timedelta(seconds=interval * i) - datetime.timedelta(seconds=0)).strftime('%Y-%m-%d %H:%M:%S'),
                "year": "year={0}".format((start_interval - datetime.timedelta(seconds=interval * i)).strftime('%Y')),
                "month": "month={0}".format((start_interval - datetime.timedelta(seconds=interval * i)).strftime('%m'))
            }
        )
    return parameter


if __name__ == '__main__':
    
    parameter = parameter()

    file_system_query = """
        select distinct substr(option, '[0-9]') as nk
             , option as current_name
             , option as historical_name
             , '2020-01-01' as start_date
             --, to_char(cast(timeofday() as date), 'yyyy-MM-dd') as start_date
          from table(dfs.`/home/danilo/Documents/warehouse/df.csv`(type => 'text', fieldDelimiter => ';', extractHeader => true, schema => 'inline=(id varchar, code integer, option varchar, description varchar, value double, rate double, created_at timestamp properties {`drill.format` = `yyyy-MM-dd HH:mm:ss.SSSSSS`}, updated_at timestamp properties {`drill.format` = `yyyy-MM-dd HH:mm:ss.SSSSSS`}, status boolean)'))
         where /*dir0 = '%(year)s'
           and dir1 = '%(month)s'
           and */created_at >= '%(start_interval)s' and created_at < '%(end_interval)s'
    """
    
    stage_table_creation = """
        create temp table stg_option(
            nk              integer,
            current_name    character varying,
            historical_name character varying unique,
            start_date      date
        )
    """
    
    table_merge = """
        insert into dim_option(nk, current_name, historical_name, start_date)
            select nk
                 , current_name
                 , historical_name
                 , start_date
              from stg_option
        on conflict(historical_name)
        do nothing
        --do update set historical_name = excluded.historical_name--, updated_at = now()
        --    where dim_lob.name <> excluded.name
        --       or dim_lob.name is null
    """
    
    main(file_system_query, parameter, stage_table_creation, table_merge)