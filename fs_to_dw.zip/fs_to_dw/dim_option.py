#!/usr/bin/env python
# coding: utf-8

import datetime
import logging

from fs_to_dw import read_file_system
from fs_to_dw import json_to_csv
from fs_to_dw import load_pgsql

if __name__ == '__main__':
    
    logging.basicConfig(filename='log/{0}.log'.format(__file__.replace('.py', '')), level=logging.CRITICAL, format='[%(asctime)s %(levelname)s %(name)s] %(message)s')
    logger = logging.getLogger(__name__)
    
    ################################################### parameter ###################################################
    interval = 86400
    period = 365 * 2
    end_interval = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

    while end_interval < datetime.datetime.now():
        end_interval += datetime.timedelta(seconds=interval)
    start_interval = end_interval - datetime.timedelta(seconds=interval)

    parameter = []
    for i in range(period):
        parameter.append(
            {
                "start_interval": (start_interval - datetime.timedelta(seconds=interval * i)).strftime('%Y-%m-%d %H:%M:%S'),
                "end_interval": (end_interval - datetime.timedelta(seconds=interval * i) - datetime.timedelta(seconds=0)).strftime('%Y-%m-%d %H:%M:%S'),
                "year": "year={0}".format((start_interval - datetime.timedelta(seconds=interval * i)).strftime('%Y')),
                "month": "month={0}".format((start_interval - datetime.timedelta(seconds=interval * i)).strftime('%m'))
            }
        )
    
    #parameter = [{"interaction_number": 1}]
    #################################################################################################################

    file_system_query = """
        select distinct substr(option, '[0-9]') as nk
             , option as current_name
             , option as historical_name
             , '2020-01-01' as start_date
             --, to_char(cast(timeofday() as date), 'yyyy-MM-dd') as start_date
          from table(dfs.`/home/danilo/Documents/warehouse/df.csv`(type => 'text', fieldDelimiter => ';', extractHeader => true, schema => 'inline=(id varchar, code integer, option varchar, description varchar, value double, rate double, created_at timestamp properties {`drill.format` = `yyyy-MM-dd HH:mm:ss.SSSSSS`}, updated_at timestamp properties {`drill.format` = `yyyy-MM-dd HH:mm:ss.SSSSSS`}, status boolean)'))
         where /*dir0 = '%(year)s'
           and dir1 = '%(month)s'
           and */created_at >= '%(start_interval)s' and created_at < '%(end_interval)s'
    """
    
    stage_table_creation = """
        create temp table stg_option(
            nk              integer,
            current_name    character varying,
            historical_name character varying unique,
            start_date      date
        )
    """
    
    table_merge = """
        insert into dim_option(nk, current_name, historical_name, start_date)
            select nk
                 , current_name
                 , historical_name
                 , start_date
              from stg_option
        on conflict(historical_name)
        do nothing
        --do update set name = excluded.name, updated_at = now()
        --    where dim_lob.name <> excluded.name
        --       or dim_lob.name is null
    """
    
    try:
        for value in parameter:
            data = read_file_system(file_system_query, value)
            if data:
                output = json_to_csv(data)
                load_pgsql(stage_table_creation, output, table_merge)
            else:
                logger.warning('Query returns empty!')
    except Exception as e:
        logger.critical(e)