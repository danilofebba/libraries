create database dw_pags

create sequence if not exists sq_option;

create table if not exists dim_option(
    sk                integer                     not null default nextval('sq_option'),
    nk                integer                     not null,
    hierarchical_nk   integer[]                       null,
    current_name      character varying           not null,
    historical_name   character varying           not null,
    start_date        date                        not null,
    end_date          date                        not null default '9999-12-31',
    current_flag      boolean                     not null default true,
    created_at        timestamp without time zone not null default (current_timestamp at time zone 'UTC'),
    updated_at        timestamp without time zone not null default (current_timestamp at time zone 'UTC'),
    constraint pk_option primary key(sk),
    constraint uq_option unique(historical_name)
);

insert into dim_option(sk, nk, current_name, historical_name, start_date)
    values(-1, -1, 'uncategorized', 'uncategorized', '2020-01-01');

create sequence if not exists sq_test_interval;

create table if not exists fact_test_interval(
    id                  bigint                      not null default nextval('sq_test_interval'),
    option_sk           integer                     not null,
    date_sk             integer                     not null,
    time_sk             integer                     not null,
    value               double precision                null,
    amount              integer                         null,
    created_at          timestamp without time zone not null default (current_timestamp at time zone 'UTC'),
    updated_at          timestamp without time zone not null default (current_timestamp at time zone 'UTC'),
    logical_delete_flag boolean                     not null default false,
    constraint pk_test_interval primary key(id),
    constraint uq_test_interval unique(option_sk, date_sk, time_sk)
);


