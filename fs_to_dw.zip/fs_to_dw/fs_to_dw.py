#!/usr/bin/env python
# coding: utf-8

import urllib.request
import json
import re
import io
import psycopg2

def read_file_system(file_system_query, parameter):
    try:
        url = 'http://localhost:8047/status'
        method = 'GET'
        request = urllib.request.Request(url=url, method=method)
        with urllib.request.urlopen(request) as f:
            response = f.read().decode('utf-8')
        if not re.search('Running!', response):
            raise Exception('Apache Drill not is running!')
            
        url = 'http://localhost:8047/query.json'
        data = json.dumps({'queryType': 'SQL', 'query': file_system_query%parameter}).encode('utf-8')
        headers = {'Content-Type': 'application/json'}
        method = 'POST'
        request = urllib.request.Request(url=url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(request) as f:
            response = f.read().decode('utf-8')
            
        if json.loads(response)['queryState'] == 'FAILED':
            raise Exception('Query failed!')
            
        return json.loads(response)['rows']
            
    except Exception as e:
        raise Exception(e)

def json_to_csv(data):
    output = io.StringIO()
    string = []
    for row in data:
        for value in row:
            if row[value]:
                string.append(str(row[value]))
            else:
                string.append('')
        output.write(';'.join(string) + '\n')
        string = []
    output.seek(0)
    return output

def load_pgsql(stage_table_creation, output, table_merge):
    try:
        connection = psycopg2.connect(host='192.168.43.3',port='5432',dbname='dw_pags',user='postgres',password='123456')
        cursor = connection.cursor()
        
        cursor.execute(stage_table_creation)
        connection.commit()
        
        cursor.copy_from(file=output, table='{0}'.format(re.search('table ([a-zA-Z0-9_-]+)', stage_table_creation).group(1)), sep=';', null='')
        connection.commit()
        
        cursor.execute(table_merge)
        connection.commit()
        rows_number = cursor.rowcount
        
        cursor.close()
        connection.close()

        return rows_number
    except Exception as e:
        raise Exception(e)